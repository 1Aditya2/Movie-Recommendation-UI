import uvicorn
from fastapi import FastAPI
import numpy as np
import pickle
import pandas as pd
from MovieSchema import movieName
import requests
from fastapi.middleware.cors import CORSMiddleware
#pip install fastapi uvicorn
# 2. Create the app object
app = FastAPI()
origins=[
    "http://localhost:3000"
    
    ]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

movies = pickle.load(open('movie_list.pkl','rb'))
similarity = pickle.load(open('similarity.pkl','rb'))
'''
def fetch_poster(movie_id):
    url = "https://api.themoviedb.org/3/movie/{}?api_key=59a588a99f49d72dc769ddbe02e0b175&language=en-US".format(movie_id)
    data = requests.get(url)
    data = data.json()
    poster_path = data['poster_path']
    full_path = "https://image.tmdb.org/t/p/w500/" + poster_path
    return full_path
'''

@app.get('/')
def index():
    return {'message':'Hey yaa!'}

@app.post('/recommend')
def recommend(data:movieName):
    data=data.dict()
    movie=data['movie']
    index = movies[movies['title'] == movie].index[0]
    distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])
    recommended_movie_names = []
    recommended_movie_id = []
    for i in distances[1:6]:
        # fetch the movie poster
        movie_id = movies.iloc[i[0]].movie_id
        #recommended_movie_posters.append(fetch_poster(movie_id))
        recommended_movie_id.append(str(movie_id))
        recommended_movie_names.append(movies.iloc[i[0]].title)

    return {'recommended_Movies_Name':recommended_movie_names,'recommended_Movies_Id':recommended_movie_id}

if __name__ == '__main__':
    uvicorn.run(app, host='127.0.0.1', port=8000)

#uvicorn dlf:app --reload









