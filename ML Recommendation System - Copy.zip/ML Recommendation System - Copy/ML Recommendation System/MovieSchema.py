# -*- coding: utf-8 -*-
"""
Created on Sun May 14 16:59:26 2023

@author: asus
"""

from pydantic import BaseModel
class movieName(BaseModel):
    movie: str